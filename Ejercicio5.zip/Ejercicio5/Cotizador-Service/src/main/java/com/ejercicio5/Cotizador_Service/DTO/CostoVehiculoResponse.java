package com.ejercicio5.Cotizador_Service.DTO;

public class CostoVehiculoResponse {
    private double costo;
}

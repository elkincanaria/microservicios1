package com.ejercicio5.Cotizador_Service.Service;

import org.springframework.stereotype.Service;

@Service
public class CostoVehiculoService {
    public double calcularCosto(double distancia, String tipoVehiculo) {

        double costoKm;

        switch (tipoVehiculo.toUpperCase()) {
            case "AUTO":
                costoKm = 200;
                break;
            case "MOTO":
                costoKm = 70;
                break;
            case "AUTO ELECTRICO":
                costoKm = 60;
                break;
            default:
                throw new RuntimeException("Tipo de vehículo inválido");
        }

        return distancia * costoKm;
    }
}

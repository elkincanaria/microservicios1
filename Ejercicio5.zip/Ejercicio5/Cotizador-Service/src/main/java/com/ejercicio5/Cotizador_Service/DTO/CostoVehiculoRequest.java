package com.ejercicio5.Cotizador_Service.DTO;

public class CostoVehiculoRequest {
    private double distancia;
    private String tipoVehiculo;
}

package com.ejercicio5.Cotizador_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CotizadorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.ejercicio5.Flota_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlotaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

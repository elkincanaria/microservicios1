package com.ejercicio5.Flota_Service.DTO;
import com.ejercicio5.Vehiculo_Service.Entity.Vehiculo;

public class FlotaResponse {

    private Vehiculo vehiculo;
    private double costo;

    public FlotaResponse() {}

    public FlotaResponse(Vehiculo vehiculo, double costo) {
        this.vehiculo = vehiculo;
        this.costo = costo;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }

    public double getCosto() {
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }
}
package com.ejercicio5.Flota_Service.Service;

import com.ejercicio5.Flota_Service.DTO.FlotaResponse;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class GestionFlotaService {

    private final RestTemplate clientHttp = new RestTemplate();

    private static final String URL_VEHICULOS = "http://localhost:8081/vehiculos";
    private static final String URL_COTIZACION = "http://localhost:8082/cotizar";

    public List<FlotaResponse> calcularCostoTotal(double km) {

        ResponseEntity<Vehiculo[]> respuestaVehiculos =
                clientHttp.getForEntity(URL_VEHICULOS, Vehiculo[].class);

        Vehiculo[] listaVehiculos = respuestaVehiculos.getBody();

        List<FlotaResponse> listaResultado = new ArrayList<>();

        if (listaVehiculos == null) {
            return listaResultado;
        }

        for (Vehiculo vehiculo : listaVehiculos) {

            CotizacionRequest peticion =
                    new CotizacionRequest(km, vehiculo.getTipo());

            CotizacionResponse respuestaCotizacion =
                    clientHttp.postForObject(
                            URL_COTIZACION,
                            peticion,
                            CotizacionResponse.class
                    );

            double valorFinal = (respuestaCotizacion != null)
                    ? respuestaCotizacion.getCosto()
                    : 0.0;

            FlotaResponse respuesta =
                    new FlotaResponse(vehiculo, valorFinal);

            listaResultado.add(respuesta);
        }

        return listaResultado;
    }
}
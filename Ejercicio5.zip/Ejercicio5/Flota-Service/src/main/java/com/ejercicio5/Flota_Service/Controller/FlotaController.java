package com.ejercicio5.Flota_Service.Controller;

import com.ejercicio5.Flota_Service.DTO.FlotaResponse;
import com.ejercicio5.Flota_Service.Service.FlotaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/flota")
public class FlotaController {

    @Autowired
    private FlotaService flotaService;

    @GetMapping("/{distancia}")
    public List<FlotaResponse> obtener(@PathVariable double distancia) {
        return flotaService.obtenerCostoFlota(distancia);
    }
}

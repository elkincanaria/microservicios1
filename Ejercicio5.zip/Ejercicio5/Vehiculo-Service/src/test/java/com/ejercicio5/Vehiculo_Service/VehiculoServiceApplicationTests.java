package com.ejercicio5.Vehiculo_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehiculoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

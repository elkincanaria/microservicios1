package com.ejercicio5.Vehiculo_Service.Repository;

import com.ejercicio5.Vehiculo_Service.Entity.Moto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MotoRepository extends JpaRepository < Moto, Long > {

}

package com.ejercicio5.Vehiculo_Service.Service;

import com.ejercicio5.Vehiculo_Service.Entity.AutoElectrico;
import com.ejercicio5.Vehiculo_Service.Repository.AutoElectricoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AutoElectricoService {
    @Autowired
    private AutoElectricoRepository AutoElectricorepo;

    public Optional<AutoElectrico> findByIdAutoElectrico(Long id)
    {
        return AutoElectricorepo.findById(id);
    }

    public List<AutoElectrico> findAllAutoElectrico()
    {
        return AutoElectricorepo.findAll();
    }

    public AutoElectrico saveAutoElectrico(AutoElectrico m1)
    {
        return AutoElectricorepo.save(m1);
    }

    public void deleteAutoElectrico(Long id)
    {
        AutoElectricorepo.deleteById(id);
    }

}

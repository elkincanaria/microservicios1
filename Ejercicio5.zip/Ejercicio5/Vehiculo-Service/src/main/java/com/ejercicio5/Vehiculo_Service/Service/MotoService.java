package com.ejercicio5.Vehiculo_Service.Service;

import com.ejercicio5.Vehiculo_Service.Entity.Moto;
import com.ejercicio5.Vehiculo_Service.Repository.MotoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MotoService {
    @Autowired
    private MotoRepository motorepo;

    public Optional<Moto> findByIdMoto(Long id)
    {
        return motorepo.findById(id);
    }

    public List<Moto> findAllMoto()
    {
        return motorepo.findAll();
    }

    public Moto saveMoto(Moto m1)
    {
        return motorepo.save(m1);
    }

    public void deleteMoto(Long id)
    {
        motorepo.deleteById(id);
    }

}

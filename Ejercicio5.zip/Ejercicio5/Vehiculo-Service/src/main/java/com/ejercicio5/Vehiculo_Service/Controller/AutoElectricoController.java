package com.ejercicio5.Vehiculo_Service.Controller;

import com.ejercicio5.Vehiculo_Service.Entity.AutoElectrico;
import com.ejercicio5.Vehiculo_Service.Service.AutoElectricoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/auto")
public class AutoElectricoController {
    @Autowired
    private AutoElectricoService autoService;

    @GetMapping
    public List<AutoElectrico> findAllAutoElectrico()
    {
        return autoService.findAllAutoElectrico();
    }

    @GetMapping("/{id}")
    public Optional<AutoElectrico> findByIdAutoElectrico(@PathVariable Long id)
    {
        return autoService.findByIdAutoElectrico(id);
    }

    @PostMapping
    public AutoElectrico saveAutoElectrico(@RequestBody AutoElectrico m1)
    {
        return autoService.saveAutoElectrico(m1);
    }

    @PatchMapping
    public AutoElectrico updateAutoElectrico(@RequestBody AutoElectrico m1)
    {
        return autoService.saveAutoElectrico(m1);
    }

    @DeleteMapping("/{id}")
    public void deleteByIdAutoElectrico(@PathVariable Long id)
    {
        autoService.deleteAutoElectrico(id);
    }

}

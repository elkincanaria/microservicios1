package com.ejercicio5.Vehiculo_Service.Entity;

import jakarta.persistence.Entity;

@Entity
public class Auto extends Vehiculo {

    double costoPorKm;

    public Auto(String marca, String modelo, int anio, double costoPorKm) {
        super(marca, modelo, anio);
        this.costoPorKm = costoPorKm;
    }
}

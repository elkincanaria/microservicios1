package com.ejercicio5.Vehiculo_Service.Service;

import com.ejercicio5.Vehiculo_Service.Entity.Auto;
import com.ejercicio5.Vehiculo_Service.Repository.AutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AutoService {
    @Autowired
    private AutoRepository Autorepo;

    public Optional<Auto> findByIdAuto(Long id)
    {
        return Autorepo.findById(id);
    }

    public List<Auto> findAllAuto()
    {
        return Autorepo.findAll();
    }

    public Auto saveAuto(Auto m1)
    {
        return Autorepo.save(m1);
    }

    public void deleteAuto(Long id)
    {
        Autorepo.deleteById(id);
    }

}

package com.ejercicio5.Vehiculo_Service.Entity;

import jakarta.persistence.Entity;

@Entity
public class AutoElectrico extends Vehiculo {

    private double WhPorKm;
    private double bateria; // porcentaje
    private double tiempoCarga; // horas

    public AutoElectrico(String marca, String modelo, int anio,
                         double WhPorKm,
                         double bateria, double tiempoCarga) {

        super(marca, modelo, anio);
        this.WhPorKm = WhPorKm;
        this.bateria = bateria;
        this.tiempoCarga = tiempoCarga;
    }
}

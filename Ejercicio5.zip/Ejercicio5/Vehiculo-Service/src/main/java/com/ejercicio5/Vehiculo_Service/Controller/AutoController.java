package com.ejercicio5.Vehiculo_Service.Controller;

import com.ejercicio5.Vehiculo_Service.Entity.Auto;
import com.ejercicio5.Vehiculo_Service.Service.AutoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/auto")
public class AutoController {
    @Autowired
    private AutoService autoService;

    @GetMapping
    public List<Auto> findAllAuto()
    {
        return autoService.findAllAuto();
    }

    @GetMapping("/{id}")
    public Optional<Auto> findByIdAuto(@PathVariable Long id)
    {
        return autoService.findByIdAuto(id);
    }

    @PostMapping
    public Auto saveAuto(@RequestBody Auto m1)
    {
        return autoService.saveAuto(m1);
    }

    @PatchMapping
    public Auto updateAuto(@RequestBody Auto m1)
    {
        return autoService.saveAuto(m1);
    }

    @DeleteMapping("/{id}")
    public void deleteByIdAuto(@PathVariable Long id)
    {
        autoService.deleteAuto(id);
    }


}

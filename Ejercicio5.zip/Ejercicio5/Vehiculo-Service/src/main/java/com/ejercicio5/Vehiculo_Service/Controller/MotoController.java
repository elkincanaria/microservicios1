package com.ejercicio5.Vehiculo_Service.Controller;

import com.ejercicio5.Vehiculo_Service.Entity.Moto;
import com.ejercicio5.Vehiculo_Service.Service.MotoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/moto")
public class MotoController {
    @Autowired
    private MotoService motoService;

    @GetMapping
    public List<Moto> findAllMoto()
    {
        return motoService.findAllMoto();
    }

    @GetMapping("/{id}")
    public Optional<Moto> findByIdMoto(@PathVariable Long id)
    {
        return motoService.findByIdMoto(id);
    }

    @PostMapping
    public Moto saveMoto(@RequestBody Moto m1)
    {
        return motoService.saveMoto(m1);
    }

    @PatchMapping
    public Moto updateMoto(@RequestBody Moto m1)
    {
        return motoService.saveMoto(m1);
    }

    @DeleteMapping("/{id}")
    public void deleteByIdMoto(@PathVariable Long id)
    {
        motoService.deleteMoto(id);
    }


}

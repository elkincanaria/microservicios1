package com.ejercicio5.Vehiculo_Service.Repository;

import com.ejercicio5.Vehiculo_Service.Entity.Auto;
import com.ejercicio5.Vehiculo_Service.Entity.AutoElectrico;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AutoElectricoRepository extends JpaRepository<AutoElectrico, Long > {

}
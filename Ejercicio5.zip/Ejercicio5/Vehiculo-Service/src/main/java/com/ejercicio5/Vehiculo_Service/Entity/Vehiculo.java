package com.ejercicio5.Vehiculo_Service.Entity;

import jakarta.persistence.Entity;

@Entity
public class Vehiculo {

    String marca;
    String modelo;
    int anio;

    public Vehiculo(String marca, String modelo, int anio) {
        this.marca = marca;
        this.modelo = modelo;
        this.anio = anio;
    }
}

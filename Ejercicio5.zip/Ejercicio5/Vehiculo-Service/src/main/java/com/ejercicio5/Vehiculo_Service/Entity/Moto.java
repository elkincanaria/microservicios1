package com.ejercicio5.Vehiculo_Service.Entity;

import jakarta.persistence.Entity;

@Entity
public class Moto extends Vehiculo {

    private Long idMoto;
    double costoPorKm;

    public Moto(String marca, String modelo, int anio, double costoPorKm) {
        super(marca, modelo, anio);
        this.costoPorKm = costoPorKm;
    }
}
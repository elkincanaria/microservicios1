package com.ejercicio5.Vehiculo_Service.Repository;

import com.ejercicio5.Vehiculo_Service.Entity.Auto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AutoRepository extends JpaRepository<Auto, Long > {

}


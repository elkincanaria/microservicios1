package org.example.ejercicio1;

public interface Serializable {

    String serializar();

}

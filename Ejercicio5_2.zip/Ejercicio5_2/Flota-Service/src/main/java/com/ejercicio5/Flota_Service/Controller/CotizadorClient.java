package com.ejercicio5.Flota_Service.Controller;


// Anotación mágica: Ve a Eureka, busca COTIZADOR-SERVICE y dispara la petición.
@FeignClient(name = "COTIZADOR-SERVICE")
public interface CotizadorClient {

    @GetMapping("/api/cotizar")
    double calcularCosto(@RequestParam String tipoVehiculo, @RequestParam double km);

}


package com.example.ejercicio2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioClaseApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.ejercicio2;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {

        // Main.java

        Factura factura = new Factura("F-001");

        // Añadir productos
        factura.agregarItem(new Producto(
                "Laptop", 999.99, 1));
        factura.agregarItem(new Producto(
                "Mouse", 25.00, 2));

        // Añadir servicios (misma lista!)
        factura.agregarItem(new Servicio(
                "Soporte Técnico", 80.0, 3));

        factura.imprimir();
        // Total: $999.99 + $50.00 + $240.00
        // TOTAL: $1289.99

        }
    }